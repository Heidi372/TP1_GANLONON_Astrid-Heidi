#include <SDL2/SDL.h>
#include "./SDL2_image/SDL_image.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "fonctions_SDL.h"
#include "./SDL2_ttf/SDL_ttf.h"


SDL_Texture* charger_texte(const char* message, SDL_Renderer* renderer,TTF_Font *font, SDL_Color color){
	
	SDL_Surface *surface = NULL;
	SDL_Texture *tex = NULL;
	

	
	// Écrire le texte sur une surface SDL
	surface= TTF_RenderText_Solid(font, message, color) ;

	tex= SDL_CreateTextureFromSurface(renderer, surface) ;

	return tex;

	// Fermer la police
	TTF_CloseFont(font) ;

	// Fermer SDL_ttf
	TTF_Quit() ;	
	}

SDL_Texture* charger_image_transparente(const char* nomfichier, SDL_Renderer* renderer, Uint8 r, Uint8 g, Uint8 b){

	SDL_Surface *surface = NULL;
	SDL_PixelFormat *fmt = NULL;
	SDL_Texture *tex = NULL;
	Uint32 key;
	int color;

	surface= SDL_LoadBMP(nomfichier) ;

	fmt= surface->format;


	// Récupérer la valeur (RGB) du pixel au format donné.
	key= SDL_MapRGB(fmt, r,  g, b);

	// Définir la couleur (pixel transparent) dans une surface.
	color=SDL_SetColorKey(surface , 0, key) ;

	tex= SDL_CreateTextureFromSurface(renderer, surface) ;

	return tex;

	// Libérer une surface
	SDL_FreeSurface(surface) ;

	// Libérer une texture
	SDL_DestroyTexture(tex) ;
	
}

 
SDL_Texture* charger_image (const char* nomfichier, SDL_Renderer* renderer){
	
	//SDL_Window *window = NULL;
    	//SDL_Renderer *renderer = NULL;
    	SDL_Texture *bitmapTex = NULL;
	SDL_Surface *bitmapSurface = NULL;
    	//int posX = 100, posY = 100, width = 320, height = 240;

	SDL_Init(SDL_INIT_VIDEO);
	//window = SDL_CreateWindow("Hello World", posX, posY, width, height, 0);
	
	// Créer un contexte de rendu (renderer) pour l’image
	//renderer = SDL_CreateRenderer(window,-1, SDL_RENDERER_ACCELERATED) ;

	// Charger une image
	bitmapSurface= SDL_LoadBMP(nomfichier) ;

	// Convertir la surface de l’image au format texture avant de l’appliquer
	bitmapTex= SDL_CreateTextureFromSurface(renderer, bitmapSurface) ;

	// Copier (une partie de) la texture dans le renderer
	SDL_RenderCopy(renderer, bitmapTex, NULL, NULL) ;

	// Récupérer les attributs d’une texture
	SDL_QueryTexture(bitmapTex, NULL, NULL, 0, 0) ;
	
	return bitmapTex;

	// Libérer une surface
	SDL_FreeSurface(bitmapSurface) ;

	// Libérer une texture
	SDL_DestroyTexture(bitmapTex) ;

	

	
}
