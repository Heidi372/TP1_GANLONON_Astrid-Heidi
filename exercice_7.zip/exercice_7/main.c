#include <SDL2/SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "./SDL2_image/SDL_image.h"
#include "./SDL2_ttf/SDL_ttf.h"
#include "fonctions_SDL.h"


int main(int argc, char *argv[])
{
	SDL_Window* fenetre; // Déclaration de la fenêtre
	SDL_Event evenements; // Événements liés à la fenêtre

	// Mettre en place un contexte de rendu de l’écran
	SDL_Renderer* ecran;
	ecran = SDL_CreateRenderer(fenetre, -1, SDL_RENDERER_ACCELERATED);

	


	bool terminer = false;

	if(SDL_Init(SDL_INIT_VIDEO) < 0) // Initialisation de la SDL
	{
		printf("Erreur d’initialisation de la SDL: %s",SDL_GetError());
		SDL_Quit();
		return EXIT_FAILURE;
	}

	// Créer la fenêtre
	fenetre = SDL_CreateWindow("Fenetre SDL", SDL_WINDOWPOS_CENTERED,
	SDL_WINDOWPOS_CENTERED, 1400, 900, SDL_WINDOW_RESIZABLE);

	if(fenetre == NULL) // En cas d’erreur
	{
		printf("Erreur de la creation d’une fenetre: %s",SDL_GetError());
		SDL_Quit();
		return EXIT_FAILURE;
	}

	//Initialisation du font
	if(TTF_Init()==-1) {
    		printf("TTF_Init: %s\n", TTF_GetError());
    		return EXIT_FAILURE;
	}



	
	// Charger l’image
	SDL_Texture* fond = charger_image( "fond.bmp", ecran );
	SDL_RenderCopy(ecran, fond, NULL, NULL);

	// Charger l’image avec la transparence
	Uint8 r = 255, g = 255, b = 255;
	SDL_Texture* obj = charger_image_transparente("obj.bmp", ecran,r,g,b);

	SDL_Rect SrcR,DestR;
	SrcR.x = 0;
	SrcR.y = 0;
	SrcR.w = 640; //Largeur de l'objet en pixels (à récupérer)
	SrcR.h = 192; //Hauteur de l'objet en pixels (à récupérer)

	DestR.x = 350;
	DestR.y = 350;
	DestR.w = 640/3;
	DestR.h = 192/3;
	
	SDL_RenderCopy(ecran, obj, &SrcR, &DestR);

	//Charger sprites avec la transparence
	SDL_Texture* sprites = charger_image_transparente("sprites.bmp", ecran,r,g,b);

	SDL_Rect DestR_sprite[6],SrcR_sprite;

	SrcR_sprite.x = 0;
	SrcR_sprite.y = 0;
	SrcR_sprite.w = 285; // Largeur du sprite
	SrcR_sprite.h = 250; // Hauteur du sprite

	for(int i=0; i<6; i++)
	{
		DestR_sprite[i].x = i > 2 ? 60*(i+1)+100 : 60*(i+1);
		DestR_sprite[i].y = i > 2 ? 60 : 120;
		DestR_sprite[i].w = 285/3; // Largeur du sprite
		DestR_sprite[i].h = 250/2; // Hauteur du sprite
		SDL_RenderCopy(ecran, sprites, &SrcR_sprite, &DestR_sprite[i]);

	}

	TTF_Font *font = TTF_OpenFont("./arial.ttf",28);
	SDL_Color color = {0,0,0,0};
	char msg[] = "TP sur Makefile et SDL";
	SDL_Texture* texte = charger_texte(msg,ecran,font,color);
	SDL_Rect text_pos; // Position du texte
	text_pos.x = 10;
	text_pos.y = 100;
	text_pos.w = 200; // Largeur du texte en pixels (à récupérer)
	text_pos.h = 15; // Hauteur du texte en pixels (à récupérer)
		
	SDL_RenderCopy(ecran,texte,NULL,&text_pos);

	// Boucle principale
	while(!terminer){

		

		//SDL_PollEvent ...
		SDL_PollEvent( &evenements );
		switch(evenements.type)
		{
			case SDL_QUIT:
			terminer = true; 
                        break;
			case SDL_KEYDOWN:
			switch(evenements.key.keysym.sym)
			{
				case SDLK_ESCAPE:
				case SDLK_q:
				terminer = true; 
                                break;
			}
		}
		
		SDL_RenderPresent(ecran);
	}

	SDL_RenderClear(ecran);
	
	// Fermer la police et quitter SDL_ttf
	TTF_CloseFont( font );
	TTF_Quit();

	// Libérer de la mémoire
	SDL_DestroyTexture(fond);
	SDL_DestroyTexture(obj);
	SDL_DestroyTexture(sprites);
	SDL_DestroyRenderer(ecran);

	// Quitter SDL
	SDL_DestroyWindow(fenetre);
	SDL_Quit();
	return 0;
}
