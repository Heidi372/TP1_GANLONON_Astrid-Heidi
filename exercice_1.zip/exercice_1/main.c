#include <stdio.h>
#include <stdlib.h>
#include "addition.h"
#include "addition.c"



int main()
{
    int a;
    int b;
    int c;

    scanf("%d",&a);
    scanf("%d",&b);

    c = somme(a,b);

    printf("%d",c);

    return 0;
}
