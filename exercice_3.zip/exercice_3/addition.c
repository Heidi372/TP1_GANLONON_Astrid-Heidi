#include <stdio.h>
#include <stdlib.h>
#include "addition.h"

int somme (int a, int b)
{
    int c;

    c = a + b;

    return (c);
}
