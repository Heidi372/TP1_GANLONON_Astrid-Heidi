#ifndef ADDITION_H_INCLUDED
#define ADDITION_H_INCLUDED

int somme(int a, int b);

#endif // ADDITION_H_INCLUDED
